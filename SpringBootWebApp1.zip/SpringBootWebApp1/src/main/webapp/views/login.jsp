<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>	
	
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registration Form</title>
	<link rel="stylesheet" href="css/style.css"/>
</head>

<body class="body_bg">

    <h2>Login Here</h2>
	
	
	
	<c:if test="${not empty errorMsg}">
			<h4 style="color:red"> ${errorMsg} </h4>
		</c:if>

    <form action="loginForm" method="post">

      

        Email:
        <input type="email" name="email" required>
        <br><br>

        Password:
        <input type="password" name="password" required>
        <br><br>

       

        <input type="submit" value="Login">
		
    </form> 
<br>
	
	<!-- FORGOT PASSWORD -->
	
	<form action="forgotPassword" method="get">
			       <input type="submit" value="Forgot Password">
			   </form>
		
	<br/><br/>
	
	If not registered.....<a href="regPage">Click Here</a>

</body>
</html>
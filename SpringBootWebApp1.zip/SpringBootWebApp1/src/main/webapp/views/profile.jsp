<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>	
	
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registration Form</title>
	<link rel="stylesheet" href="css/style.css"/>
</head>

<body class="body_bg">

    <h2>Welcome ${modelName}</h2>
	
	<a href="logout"> Logout </a>

</body>
</html>
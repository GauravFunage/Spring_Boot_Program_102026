<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            width: 350px;
            margin: 100px auto;
            padding: 25px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h2 {
            text-align: center;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Reset Password</h2>

        <p class="message" style="color:green">${successMsg}</p>
        <p class="message" style="color:red">${errorMsg}</p>

        <form action="${pageContext.request.contextPath}/resetPassword"
              method="post">

            <label>Email</label>
            <input type="email" name="email"
                   placeholder="Enter your registered email"
                   required>

            <label>New Password</label>
            <input type="password" name="password"
                   placeholder="Enter new password"
                   minlength="8" required>

            <button type="submit">Reset Password</button>
        </form>
    </div>

</body>
</html>